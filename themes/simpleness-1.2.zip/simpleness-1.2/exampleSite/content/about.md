---
title: About
date: 2020-09-22T10:37:58+05:30
lastmod: 
author: Rainer Chiang

description: 
categories: []
tags: []

draft: false
enableDisqus : true
enableMathJax: false
disableToC: false
disableAutoCollapse: true
---

## About Yourself

This is some static page where you can write about yourself.

## hugo theme [simpleness](https://github.com/RainerChiang/simpleness)

A hugo theme ported form [contrast-hugo](https://github.com/niklasbuschmann/contrast-hugo)
